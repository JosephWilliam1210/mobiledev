package com.uc.jowill;

import java.util.ArrayList;

public class Adapter {

    public static ArrayList<Users> dataUser = new ArrayList<>();
}
